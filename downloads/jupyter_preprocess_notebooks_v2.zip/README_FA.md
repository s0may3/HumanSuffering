# راهنمای اجرای نوت‌بوک‌ها (نسخه ۲)

✅ در این نسخه هر نوت‌بوک:

1) **raw data** را از `raw_data/` می‌خواند  
2) با همان منطق سکشن مربوطه **فیلتر/پاک‌سازی** می‌کند  
3) تعداد ردیف‌های **حذف شده** را گزارش می‌کند و چند نمونه نشان می‌دهد  
4) فایل‌های **cleaned** را در `dataset/cleaned/` تولید می‌کند  
5) فایل‌های **derived** را در `dataset/derived/` تولید می‌کند  

## شرط لازم
قبل از اجرا، مطمئن شو این فایل‌ها وجود دارند:

- `raw_data/hdx_hapi_refugees_afg.csv`
- `raw_data/hdx_hapi_idps_afg.csv`
- `raw_data/hdx_hapi_food_price_afg.csv`
- `raw_data/hdx_hapi_returnees_afg.csv`
- `raw_data/geo/afghanistan_adm1.geojson`
- `raw_data/geo/world_countries.topojson`

اگر raw_data نداری و فقط dataset داری، می‌تونی فایل‌ها رو از `dataset/` کپی کنی داخل `raw_data/` با همین اسم‌ها.
